---
inq.module: "algebra"
inq.include:
  - "**/*.md"
---
# Algebraic Pre-Core

The strongest first-principles result suggested by the algebra chats is not an identity among several appearances of the number six. It is the local--global principle that local determinacy does not entail global individuation. This module places that principle upstream of [[program-core/inq|the causal-response programme]]: algebra supplies composable distinctions, geometry records how they are presented and glued, monodromy can obstruct a global labeling, and only an additional noninvertible factual operation with persistent record extension can orient a history. Internal algebra and realized spacetime are treated as equally real mathematical regimes; their identity must be established by a typed realization, not by crossing from “mere mathematics” into something ontologically superior. Conditional on the 2026 Jacobian-counterexample preprint and the local unreviewed $A_2$ note, the cubic inverse cover is an exact model; the proposed bridges to $S^6$, KO-degree six, time, gravity, collapse, and the Standard Model remain separately typed construction problems.

## The condition for the possibility of a cosmos

A cosmos requires more than a collection of objects and more than one timeless global object. At minimum, its mathematics must make sense of:

1. **distinction:** there are generalized probes by which structure can differ;
2. **composition:** comparisons and processes can be joined coherently;
3. **locality:** some probes or presentations count as local relative to declared covers;
4. **identity through presentation:** compatible local appearances may constitute one global object;
5. **actuality:** one contextual value or branch obtains rather than merely belonging to a space of possibilities; and
6. **history:** obtained facts persist in an oriented structure of records.

The first four items belong to algebra, geometry, and [[basic-concepts/descent/inq|descent]]. The last two do not follow from them. A stack can remember every symmetry of a global object and still select no point of it. A probability law can assign every possible outcome and still actualize none. The foundational joint is therefore

$$
\boxed{
\underbrace{\text{local equivalence}
+\text{global obstruction}}_{\text{one candidate source of global nontriviality}}
+\text{typed actualizing selection}
+\text{persistent noncyclic record extension}
\longrightarrow
\text{directed factuality}.}
$$

The first pair already has exact models. A global obstruction is not logically required for every possible factual history; it is the particular source of nontriviality highlighted by these chats. Selection and record extension are separate open constructions on which the physical interpretation depends.

The programme's mathematical realism changes the form of the bridge. A realization functor relates one mathematical ontology to another; “presentation” does not mean fiction. If that functor genuinely forgets distinctions, [[algebra/nonfaithful-realization|the nonfaithfulness theorem]] proves that it cannot be an equivalence across the wall, even though reversible or unitary structure may persist inside either register.

[[algebra/quotient-unitarity-and-kernel-stabilization|Quotient unitarity and kernel stabilization]] now makes that coexistence constructive. An upstream automorphism descends through a quotient exactly when it preserves the quotient ideal; a transformation preserving a semidefinite response becomes an isometry of the radical quotient. The locally visible symmetry that lifts is therefore the image of the stabilizer of what the wall made invisible. This does not prove that loss causes unitarity, but it converts “symmetry is the grammar of appearance” into an exact quotient theorem and a precise reconstruction obligation.

[[algebra/os-descent-naturality-and-clock-no-go|OS descent naturality and
the idempotent-clock no-go]] closes the converse ambiguity. Polynomial
identities survive a surjective factor, so an idempotent expectation can
descend to a unitary only as the identity; likewise a positive Euclidean
contraction is unitary only when it is trivial. A nonfaithful OS-bounded map
can nevertheless intertwine two reconstructed clock groups when it commutes
with the separately supplied Euclidean translations. If that map is
surjective, a spectral band is absent locally exactly when the corresponding
whole spectral subspace lies in its kernel; an explicit Hilbert-semigroup
example has soft whole spectrum accumulating at zero and a fixed local gap.
Forgetting and clock
transport are therefore compatible arrows but cannot literally be the same
arrow, and the kernel must be physically derived before spectral deletion is
an explanation.

[[algebra/retract-corners-and-local-unitarity|Retract corners]] sharpen the same point without first assuming an upstream group. For a split whole-to-local map \(q\) with section \(h\), the idempotent \(e=hq\) makes the local endomorphism algebra exactly the corner \(e\operatorname{End}(W)e\). A local unitary is invertible relative to the retained identity \(e\) while its whole-carrier representative kills \(\ker q\) and is noninvertible relative to \(I_W\). With a harmonic section, the idempotent first removes the vertical response and only then exposes the reversible local grammar. [[trace-dirichlet-descent/inq|Trace Dirichlet descent]] derives the accompanying local Markov generator by infimizing a whole response over those same vertical fibres.

[[algebra/faithful-descent-rigidity-and-noiseless-unitarity|Faithful descent rigidity]] supplies the converse firewall. If the expected restriction of a normal UCP semigroup through a faithful conditional expectation is a \(*\)-automorphism of the retained algebra, then that algebra was already invariant and lies in the multiplicative domain of the whole process; under the stated invariant-state hypotheses its GNS carrier is a reducing noiseless sector and the automorphism is represented unitarily. If the corresponding \(L^2\)-implementation of the same continuous-parameter semigroup is self-adjoint, that local automorphism sector is necessarily static. Thus noisy whole dynamics and local unitary clock evolution can coexist, but faithful coarse-graining does not create the unitarity. A nontrivial clock requires a reversible component already present or a distinct reconstruction arrow.

[[modular-cocycle-tomography/inq|Modular cocycle tomography]] now supplies
the complementary visibility theorem. One faithful state detects
inner-unitary directions only modulo its centralizer; a state atlas detects
them modulo the common centralizer, which Connes cocycles express as a
commutant inside one reference presentation. A countable atlas separates any
separable factor, and a type-III\(_1\) factor admits a single faithful state
with scalar centralizer. This proves algebraic separation, not a spectral
edge: the continuum problem is the atlas's uniform closed range relative to
the physical norm.

## Algebra comes before geometry only as a doctrine

[[exceptional-context-response|Exceptional context response]] provides a finite positive realization of the same whole--part grammar. An oriented order-three automorphism determines a positive Jordan retraction and its exact variance residue. Comparing its full \(F_4\) context orbit gives a strict trace-free lower frame and a bounded reconstruction map; the regular multiplication carrier realizes that response as a matrix relative-entropy Hessian. [[primitive-peirce-response|Primitive Peirce readouts]] complete the added matrix carrier, detecting its previously unseen balance mode and supplying a certified finite entropy contraction. A field-dependent scalar direction still requires [[global-local-response-reconstruction/exceptional-context-analysis-of-gauge-gradients|the differentiated-context bridge]]; neither finite completeness nor a gradient factorization proves the physical continuum gap.

A bare algebra does not determine one geometry without qualifications. Even in commutative algebraic geometry, one declares a base, a category of algebras, admissible morphisms, and a topology before $\operatorname{Spec}$ and descent have their intended force. In noncommutative, operator-algebraic, spectral, Jordan, and octonionic settings, there is no single common spectrum that silently identifies those theories.

The proper upstream object is therefore an **algebraic doctrine**, not “the most general algebra.” It must declare or derive the scalar object, operations and identities, associativity class, involution and positivity when present, tensor product, generalized probes, covers, representations, and equivalences. [[algebra/algebra-before-geometry|Algebra before geometry]] gives the selection ledger and explains why a universal property can prove necessity only relative to its axioms.

## The exact local--global model

Conditional on the announced 2026 three-variable Keller counterexample and its local $A_2$ analysis, the inverse problem supplies a particularly clean test object. On the complement of its discriminant, the analysis gives a connected degree-three finite étale cover. Near the triple-root curve, the discriminant is analytically the $A_2$ cusp

$$
4a^3+27b^2=0
$$

times one smooth parameter. The cover has full sheet monodromy $S_3=W(A_2)$. Its rank-three pushforward algebra canonically produces a trace-zero multiplication Cartan inside an $\mathfrak{sl}_3(\mathbb C)$ bundle, with six étale-local root lines. [[algebra/a2-inverse-cover|The $A_2$ inverse cover]] states this chain and its physical boundary.

Within the conditional model, the construction proves something philosophically substantial without proving a physical theory:

> An everywhere locally valid inverse can fail to assemble into one globally single-valued inverse.

That is a failure of global individuation, not a failure of local law. Its monodromy is invertible and therefore supplies no arrow of time by itself.

There is now an unconditional positive-realization result for the ordinary real cubic family. [[algebra/a2-positive-completion|Positive completion of an $A_2$ degeneration]] proves the fiberwise type profile

$$
\bigl(\mathbb C^3,\mathbb C^2,\mathbb C\bigr)
$$

on the generic, double-root, and triple-root strata in the closure of the three-real-root chamber. These types are not canonical specialization arrows. A separately declared stabilizer action does give exact group-averaging expectations $\mathbb C^3\to\mathbb C^2\to\mathbb C$. The nonreduced singular algebras retain nilpotent thickness while every $*$-representation by bounded operators kills a self-adjoint nilpotent; this supplies exact fiberwise nonfaithful quotients and a logarithmic discriminant depth. The same-representation lemma proves only that one nonidentity bounded operator cannot be both unitary and unipotent; a representation-changing group map is not forbidden.

## Reversible identity and irreversible history

The minimum architecture has two kinds of arrow:

$$
\begin{aligned}
\text{presentation equivalences}
&\subseteq \mathcal C^{\simeq},\\
\text{physical or factive processes}
&\subseteq \operatorname{Mor}(\mathcal C).
\end{aligned}
$$

Here $\mathcal C^{\simeq}$ is the maximal subgroupoid of an ambient category $\mathcal C$. Groupoids and stacks organize reversible changes of presentation. Conditional expectations, instruments, causal precedence, and proper record extensions are generally noninvertible and live in the ambient category, not in its groupoid core. [[algebra/local-global-individuation|Local--global individuation]] develops the distinction and gives a theorem-shaped criterion for record-oriented time.

This also reconciles sufficient reason with becoming. A later fact may have a necessitating reason in the whole structure without being recoverable from the earlier observable record. Logical determination, diachronic accessibility, and invertibility of a transition are different properties.

## The sixfold firewall

The chats bring several valid structures into proximity, but numerical agreement is not yet a bridge. In particular:

$$
\begin{gathered}
|S_3|=6,\qquad |\Phi(A_2)|=6,\qquad \dim_{\mathbb R}S^6=6,\\
\operatorname{KOdim}(F)=6\pmod 8
\end{gathered}
$$

are differently typed statements. Connes' finite internal geometry has metric dimension zero; its KO-degree is exact mod-eight sign data, while [[ko-dimension-as-morita-class/inq|the graded-Morita reading]] has its own declared project status. A complex structure on the real six-sphere would make it a complex threefold, not Connes' finite geometry. The Keller map is three-dimensional over $\mathbb C$, not a derivation of three real spatial dimensions. [[algebra/type-ledger|The type ledger]] owns these distinctions.

The integrable complex structure on $S^6$ is established, but it is not an established bridge to the programme's other sixfold objects. One construction gives a compact complex threefold fibred over $\mathbb P^1$ by complex two-tori with special data of type $(3,4,\infty)$ and identifies its underlying smooth manifold with $S^6$. Its $A_2$ occurrence is a toric triangulation, not the Keller cusp or $S_3$ inverse-cover monodromy. [[algebra/s6-manuscript-branch|The integrable $S^6$ branch]] records what the theorem does and does not supply.

There is nevertheless a rigorous route by which six real dimensions can return three. For a complex threefold \(X\) with an antiholomorphic involution \(\tau\), every nonempty fixed component \(X^\tau\) is a real three-manifold. [[algebra/real-forms-and-factive-spacetime|Real forms and factive spacetime]] proves this exact statement and separates it from the open functor that would make those three-manifolds spatial objects and four-dimensional Lorentzian histories their process arrows.

There is also an independent conditional route from cyclic probes to three-space. A single bare closed line has nontrivial ambient-isotopy classes in Euclidean dimension three but not in dimension two or any dimension at least four. [[knotting-as-dimensional-presentation/inq|Knotting as three-dimensional presentation]] shows how connection holonomy motivates the one-dimensional probe, why codimension-two loop detection gives \(1+1+1=3\), and where the argument still presupposes rather than derives spatial realization.

## The new dependency order

The proposed order of construction is

$$
\begin{aligned}
&\text{algebraic doctrine and generalized probes}\\
&\longrightarrow \text{presentation category, site, and reversible descent}\\
&\longrightarrow \text{global nontriviality, with obstruction as one candidate}\\
&\longrightarrow \text{noninvertible factual process and persistent records}\\
&\longrightarrow \text{analytic and spectral realization, including any selected real form}\\
&\longrightarrow \text{causal, Lorentzian, gauge, and gravitational realization}.
\end{aligned}
$$

No lower arrow may be inferred from a shared numeral or analogy. [[algebra/theorem-programme|The theorem programme]] turns each arrow into a construction gate, with a conditional uniqueness theorem as the proper meaning of “physics from pure mathematics.” [[algebra/program-core-interface|The program-core interface]] then shows how the existing quotient, BKM, area, fact, and charge branches become downstream consumers rather than the mathematical bottom. [[algebra/cst-cwst-closure-audit|The CST/CWST closure audit]] records which current open problems these tools close, merely retype, or leave untouched.

## Present verdict

The chats were close to a genuine foundation, but the foundation is more abstract than the proposed $S^6$ identification. The exact content sought is a geometry of **presentation, obstruction, pointing, and record**. $A_2$ is the first case here with a rank-two root system and full nonabelian sheet monodromy $S_3$, not yet a uniquely selected universal singularity. A complex-threefold real form now gives one exact route to a spatial three-carrier. Time is most plausibly the orientation of proper record extension and Lorentzian history composition, not the parameter of monodromy or ordinary modular flow. Gravity could be a response cost of a noninvertible realization only after a same-carrier map to gravitational response and an independent area normalization are constructed. Quantum gravity becomes a category error only if a prior theorem first proves that metric geometry is a derived presentation and identifies the correct degrees of freedom to quantize.

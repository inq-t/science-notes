# Acceleration Condition and the CST-B2 Specialization

In a flat GR--FLRW background containing matter, radiation, and any perfect-fluid response, acceleration is controlled by one exact active-mass inequality. Inserting the CST-B2 equation of state gives a member-specific interval; the scale-state rate alone cannot decide when acceleration begins or ends because the competing densities and the selected candidate-crossing branch also enter.

Assume noninteracting matter, radiation, and a perfect-fluid response, with no additional residual sector. The total acceleration equation is equivalent to

$$
\rho_m+2\rho_r+(1+3w_X)\rho_X<0.
$$

Writing \(1+3w_X=-2+3(1+w_X)\) gives

$$
\boxed{
\bigl(2-3[1+w_X]\bigr)\rho_X
>\rho_m+2\rho_r.}
$$

This condition is necessary and sufficient under the declared background assumptions. Inserting

$$
w_X=-1+\frac{2\nu}{3}\tanh(\nu x)
$$

from [[causal-scale-theory/theorems/rigid-sech-response-identities|the CST-B2 rigid-sech theorem]] gives the CST-B2 acceleration interval after the amplitude and flatness root are chosen. Another response member retains the active-mass inequality but must supply its own \(w_X(N)\).

The sign of \(w_X+1/3\) by itself is insufficient: acceleration concerns the total active mass. In particular, on the unit branch the response density eventually dominates matter, but its negative active-mass factor tends to zero quickly enough that matter can end acceleration before the asymptotic coasting regime is reached.

A residual vacuum or an exchange current changes the inequality by adding its own active-mass contribution. No perturbation or stability statement follows from this homogeneous result.
